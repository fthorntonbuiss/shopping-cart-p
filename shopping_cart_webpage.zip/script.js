
const products = [
  {
    name: "Product 1",
    price: 10.99,
    quantity: 0,
    productId: 1,
    image: "https://example.com/product1.jpg"
  },
  {
    name: "Product 2",
    price: 20.99,
    quantity: 0,
    productId: 2,
    image: "https://example.com/product2.jpg"
  },
  {
    name: "Product 3",
    price: 30.99,
    quantity: 0,
    productId: 3,
    image: "https://example.com/product3.jpg"
  }
];

let cart = [];

function addProductToCart(productId) {
  const product = products.find(p => p.productId === productId);
  
  if (!product) {
    console.error("Product not found!");
    return;
  }
  
  const productInCart = cart.find(p => p.productId === productId);
  
  if (productInCart) {
    productInCart.quantity += 1;
  } else {
    cart.push({ ...product, quantity: 1 });
  }
  renderCart();
}

function renderCart() {
  const cartItemsDiv = document.getElementById('cart-items');
  cartItemsDiv.innerHTML = '';
  let total = 0;

  cart.forEach(product => {
    const itemDiv = document.createElement('div');
    itemDiv.textContent = `${product.name} - $${product.price} x ${product.quantity}`;
    
    const increaseBtn = document.createElement('button');
    increaseBtn.textContent = '+';
    increaseBtn.onclick = () => increaseQuantity(product.productId);

    const decreaseBtn = document.createElement('button');
    decreaseBtn.textContent = '-';
    decreaseBtn.onclick = () => decreaseQuantity(product.productId);

    const removeBtn = document.createElement('button');
    removeBtn.textContent = 'Remove';
    removeBtn.onclick = () => removeProductFromCart(product.productId);

    itemDiv.appendChild(increaseBtn);
    itemDiv.appendChild(decreaseBtn);
    itemDiv.appendChild(removeBtn);
    cartItemsDiv.appendChild(itemDiv);

    total += product.price * product.quantity;
  });

  document.getElementById('cart-total').textContent = total.toFixed(2);
}

function increaseQuantity(productId) {
  const productInCart = cart.find(p => p.productId === productId);
  
  if (productInCart) {
    productInCart.quantity += 1;
  }
  renderCart();
}

function decreaseQuantity(productId) {
  const productInCart = cart.find(p => p.productId === productId);
  
  if (productInCart) {
    if (productInCart.quantity > 1) {
      productInCart.quantity -= 1;
    } else {
      removeProductFromCart(productId);
    }
  }
  renderCart();
}

function removeProductFromCart(productId) {
  cart = cart.filter(p => p.productId !== productId);
  renderCart();
}

function checkout() {
  const total = parseFloat(document.getElementById('cart-total').textContent);
  alert(`Thank you for your purchase! Total: $${total}`);
  cart = [];
  renderCart();
}
